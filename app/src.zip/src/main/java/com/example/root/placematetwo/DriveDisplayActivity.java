package com.example.root.placematetwo;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DriveDisplayActivity extends AppCompatActivity {

    ListView lvCompanyName;
    ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drive_display);


        Intent intent = getIntent();
        final int driveId = intent.getIntExtra("driveId",0);


        final ProgressDialog progressDialog = new ProgressDialog(DriveDisplayActivity.this,
                R.style.Theme_AppCompat_Light_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // On complete call either onLoginSuccess or onLoginFailed


                        Response.Listener<String> responseListener=new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                try {
                                    JSONObject jsonResponse=new JSONObject(response);
                                    final int total = jsonResponse.getInt("total");
                                    if(total==0){


                                        Toast.makeText(DriveDisplayActivity.this,"Oops! No data found",Toast.LENGTH_SHORT).show();
                                        progressDialog.dismiss();

                                    }else{


                                        String dataRes[] = new String[13];

                                        for (int i=1;i<=13;i++) {
                                            dataRes[i-1] = jsonResponse.getString(Integer.toString(i));


                                        }


                                        lvCompanyName = (ListView) findViewById(android.R.id.list);
                                        adapter = new ArrayAdapter<String>(DriveDisplayActivity.this,android.R.layout.simple_list_item_1,dataRes);
                                        lvCompanyName.setAdapter(adapter);


                                        progressDialog.dismiss();
                                        Toast.makeText(DriveDisplayActivity.this, "Data retrieved", Toast.LENGTH_LONG).show();



                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        };


                        DriveDisplayRequest driveDisplayRequest = new DriveDisplayRequest(driveId,responseListener);
                        RequestQueue queue = Volley.newRequestQueue(DriveDisplayActivity.this);
                        queue.add(driveDisplayRequest);
                    }


                }, 3000);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == android.R.id.home) {
            //call onBackPressed here
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
