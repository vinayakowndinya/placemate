package com.example.root.placematetwo;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by root on 28/2/18.
 */

public class AddBroadcastRequest extends StringRequest {
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/addBroadcastBackend.php";
    private Map<String,String> params;

    public AddBroadcastRequest(String sender,String heading, String message, Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("sender",sender);
        params.put("heading",heading);
        params.put("message",message);


    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}
