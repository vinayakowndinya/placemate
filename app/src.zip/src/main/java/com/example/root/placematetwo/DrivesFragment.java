package com.example.root.placematetwo;

import android.app.ListFragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
//import android.support.v4.app.ListFragment;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link DrivesFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link DrivesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DrivesFragment extends ListFragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public DrivesFragment() {
        // Required empty public constructor
    }




    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DrivesFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DrivesFragment newInstance(String param1, String param2) {
        DrivesFragment fragment = new DrivesFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    /*public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_drives, container, false);
    }*/
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        ViewGroup rootView = (ViewGroup)inflater.inflate(R.layout.fragment_drives,container,false);

        //to get the companies
        final ProgressDialog progressDialog = new ProgressDialog(getActivity(), R.style.Theme_AppCompat_Light_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        new Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // On complete call either onLoginSuccess or onLoginFailed


                        Response.Listener<String> responseListener=new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonResponse=new JSONObject(response);
                                    //boolean success=jsonResponse.getBoolean("success");
                                    final int total = jsonResponse.getInt("total");
                                    if(total==0){


                                        Toast.makeText(getActivity(),"No data",Toast.LENGTH_SHORT).show();
                                        progressDialog.dismiss();

                                    }else{

                                        ArrayList<DrivesListElements> arrayList = new ArrayList<DrivesListElements>();
                                        DrivesListAdapter adapter = new DrivesListAdapter(getActivity(),arrayList);

                                        setListAdapter(adapter);
                                        int dataId[] = new int[total];
                                        String dataRes[] = new String[total]; // = {"Codilar Technologies","Hindi","Tibetan","Kannada","Spanish","Mandarin","Nothing"};
                                        String dataDate[] = new String[total];
                                        String dataAggregate[] = new String[total];
                                        String dataBranch[] = new String[total];
                                        for (int i=1;i<=total;i++) {

                                            JSONObject jsonObject = new JSONObject(jsonResponse.getString(Integer.toString(i)));
                                            //dataRes[i-1] = jsonResponse.getString(Integer.toString(i));
                                            dataId[i-1] = jsonObject.getInt("driveId");
                                            dataRes[i-1] = jsonObject.getString("name");
                                            if(dataRes[i-1].length() > 20) {
                                                String temp = dataRes[i-1].substring(0,19);
                                                temp = temp + "...";
                                                dataRes[i-1] = temp;
                                            }
                                            dataDate[i-1] = jsonObject.getString("date");
                                            dataAggregate[i-1] = jsonObject.getString("aggregate");
                                            dataBranch[i-1] = jsonObject.getString("branches");

                                            DrivesListElements drivesListElements = new DrivesListElements(dataId[i-1],dataRes[i-1],dataAggregate[i-1],dataDate[i-1],dataBranch[i-1]);
                                            adapter.add(drivesListElements);
                                        }

                                        /*ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),R.layout.drives_row_layout,R.id.name,dataRes);
                                        setListAdapter(adapter);*/


                                        progressDialog.dismiss();
                                        Toast.makeText(getActivity(), "Data retrieved", Toast.LENGTH_LONG).show();



                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        };
                        DrivesRequest drivesRequest=new DrivesRequest(responseListener);
                        RequestQueue queue = Volley.newRequestQueue(getActivity());
                        queue.add(drivesRequest);

                    }


                }, 3000);






        //end of to get companies


        setRetainInstance(true);
        return rootView;
    }

    public void onListItemClick(ListView l, View v, int position, long id) {
        /*ViewGroup viewGroup = (ViewGroup) v;
        TextView txt = (TextView) viewGroup.findViewById(R.id.name);
        Toast.makeText(getActivity(),txt.getText().toString(),Toast.LENGTH_LONG).show();*/

        DrivesListElements drivesListElements = (DrivesListElements) getListView().getItemAtPosition(position);
        int did = drivesListElements.driveId;
        Intent intent = new Intent(getActivity(),DriveDisplayActivity.class);
        intent.putExtra("driveId",did);
        startActivity(intent);

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
