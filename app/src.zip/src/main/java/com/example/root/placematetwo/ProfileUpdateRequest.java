package com.example.root.placematetwo;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by root on 11/1/18.
 */


public class ProfileUpdateRequest extends StringRequest {
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/marks.php";
    private Map<String,String> params;

    public ProfileUpdateRequest(Float sem1,Float sem2,Float sem3,Float sem4,Float sem5,Float sem6,Float sem7,Float sem8,String update,String email, Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);

        String strSem1 = sem1.toString();
        String strSem2 = sem2.toString();
        String strSem3 = sem3.toString();
        String strSem4 = sem4.toString();
        String strSem5 = sem5.toString();
        String strSem6 = sem6.toString();
        String strSem7 = sem7.toString();
        String strSem8 = sem8.toString();

        params=new HashMap<>();
        params.put("sem1",strSem1);
        params.put("sem2",strSem2);
        params.put("sem3",strSem3);
        params.put("sem4",strSem4);
        params.put("sem5",strSem5);
        params.put("sem6",strSem6);
        params.put("sem7",strSem7);
        params.put("sem8",strSem8);
        params.put("email",email);
        params.put("update",update);



    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}