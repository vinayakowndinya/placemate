package com.example.root.placematetwo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;

public class GeneralUserSettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_user_settings);

        final EditText _usn = (EditText) findViewById(R.id.input_usn);
        final EditText _name = (EditText) findViewById(R.id.input_name);
        final EditText _username = (EditText) findViewById(R.id.input_username);
        final EditText _email = (EditText) findViewById(R.id.input_email);
        final EditText _passout = (EditText) findViewById(R.id.input_passout);
        final EditText _preference = (EditText) findViewById(R.id.input_preference);
        final EditText _password = (EditText) findViewById(R.id.input_password);
        final Button _update = (Button) findViewById(R.id.btn_submit);

        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),GeneralUserSettings.this.MODE_PRIVATE);
        String spemail = sharedPref.getString(getString(R.string.emailId), "");
        String spname = sharedPref.getString(getString(R.string.name), "");
        String spusername = sharedPref.getString(getString(R.string.username), "");
        String spusn = sharedPref.getString(getString(R.string.usn), "");
        String sppassout = sharedPref.getString(getString(R.string.passout), "");
        int sppreference = sharedPref.getInt(getString(R.string.preference), 0);
        String sppassword = sharedPref.getString(getString(R.string.password), "");

        _usn.setText(spusn);
        _name.setText(spname);
        _username.setText(spusername);
        _email.setText(spemail);
        _passout.setText(sppassout);
        _password.setText(sppassword);
        if(sppreference == 1)
            _preference.setText("Administrator");
        else
            _preference.setText(Integer.toString(sppreference));


        _usn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"USN update disabled",Toast.LENGTH_SHORT).show();
            }
        });

        _preference.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Preference update disabled",Toast.LENGTH_SHORT).show();
            }
        });

        _update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean valid = true;

                final String usn = _usn.getText().toString();
                final String name = _name.getText().toString();
                final String username = _username.getText().toString();
                final String email = _email.getText().toString();
                final String password = _password.getText().toString();
                final String passout = _passout.getText().toString();

                if(usn.isEmpty() || !usn.matches("[0-9]{1}[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{3}")) {
                    _usn.setError("invalid USN");
                    valid = false;
                }
                else {
                    _usn.setError(null);
                }

                if(name.isEmpty() || !name.matches("[A-Za-z ]*")) {
                    _name.setError("invalid name");
                    valid = false;
                }
                else {
                    _name.setError(null);
                }

                if(username.isEmpty() || !username.matches("[A-Za-z0-9]*")) {
                    _username.setError("invalid username");
                    valid = false;
                }
                else {
                    _username.setError(null);
                }

                if(passout.isEmpty() || !passout.matches("[0-9]{4}")) {
                    _passout.setError("invalid value");
                    valid = false;
                }
                else {
                    _passout.setError(null);
                }

                if(email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() ) {
                    _email.setError("invalid email");
                    valid = false;
                }
                else {
                    _email.setError(null);
                }

                if(!valid) {
                    Toast.makeText(getBaseContext(),"Please enter valid info",Toast.LENGTH_SHORT).show();
                }
                else {//if valid
                    _update.setEnabled(false);

                    final ProgressDialog progressDialog = new ProgressDialog(GeneralUserSettings.this,
                            R.style.Theme_AppCompat_Light_Dialog);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setMessage("Updating...");
                    progressDialog.show();

                    new android.os.Handler().postDelayed(
                            new Runnable() {
                                public void run() {
                                    // On complete call either onLoginSuccess or onLoginFailed


                                    Response.Listener<String> responseListener=new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            try {
                                                JSONObject jsonResponse=new JSONObject(response);
                                                boolean success=jsonResponse.getBoolean("success");

                                                if(!success){


                                                    Toast.makeText(getBaseContext(), "Update failed", Toast.LENGTH_LONG).show();

                                                    _update.setEnabled(true);
                                                    progressDialog.dismiss();

                                                    Intent restart  = new Intent(GeneralUserSettings.this,GeneralUserSettings.class);
                                                    startActivity(restart);
                                                    finish();

                                                }else{



                                                    SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),GeneralUserSettings.this.MODE_PRIVATE);
                                                    SharedPreferences.Editor editor = sharedPref.edit();
                                                    //editor.putInt(getString(R.string.userId), userId);
                                                    editor.putString(getString(R.string.emailId), _email.getText().toString());
                                                    editor.putString(getString(R.string.usn), usn);
                                                    editor.putString(getString(R.string.name), name);
                                                    editor.putString(getString(R.string.username), username);
                                                    editor.putString(getString(R.string.password), password);
                                                    editor.putString(getString(R.string.passout), passout);
                                                    editor.commit();


                                                    progressDialog.dismiss();
                                                    Toast.makeText(getBaseContext(), "Update Success", Toast.LENGTH_LONG).show();
                                                    _update.setEnabled(true);



                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };
                                    GeneralSettingsUpdateRequest generalSettingsUpdateRequest=new GeneralSettingsUpdateRequest(usn,name,username,email,passout,password,responseListener);
                                    RequestQueue queue = Volley.newRequestQueue(GeneralUserSettings.this);
                                    queue.add(generalSettingsUpdateRequest);

                                }


                            }, 3000);

                }
            }
        });

    }
}
