package com.example.root.placematetwo;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by root on 13/2/18.
 */

public class GeneralSettingsUpdateRequest extends StringRequest{
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/generalSettingsUpdate.php";
    private Map<String,String> params;

    public GeneralSettingsUpdateRequest(String usn, String name,String username, String email, String passout, String password, Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("username",username);
        params.put("password",password);
        params.put("usn",usn);
        params.put("name",name);
        params.put("email",email);
        params.put("passout",passout);

    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}