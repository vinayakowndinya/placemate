package com.example.root.placematetwo;

/**
 * Created by root on 1/2/18.
 */

public class DrivesListElements {
    public int driveId;
    public String cname;
    public String aggregate;
    public String date;
    public String branch;

    public DrivesListElements(int driveId,String cname,String aggregate,String date,String branches) {
        this.driveId = driveId;
        this.cname = cname;
        this.aggregate = aggregate;
        this.date = date;
        this.branch = branches;
    }
}
