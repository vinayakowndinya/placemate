package com.example.root.placematetwo;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;

public class SettingsActivity extends AppCompatActivity {
    String[] settings = {
            "Edit general profile",
            "Update marks"

    };
    String adminSettings[] = {
            "Edit general profile",
            "Update marks",
            "Create user",
            "Reports"
    };


    ListView procedure;
    ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Button btn_logout = (Button) findViewById(R.id.btn_logout);
        Button btn_delete = (Button) findViewById(R.id.btn_delete_account);



        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //for logout alert box
                AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                builder.setMessage("Do you want to logout ?")
                        .setCancelable(true)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),SettingsActivity.this.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPref.edit();
                                //editor.putInt(getString(R.string.userId), userId);
                                editor.putString(getString(R.string.emailId), "");
                                editor.commit();
                                Toast.makeText(SettingsActivity.this,"Logout successful",Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(SettingsActivity.this,LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                            }
                        });

                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Confirm Logout");
                alert.show();
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                builder.setMessage("Do you really want to delete your account ?\nAll your data will be lost from our server")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),SettingsActivity.this.MODE_PRIVATE);
                                final String email = sharedPref.getString(getString(R.string.emailId), "");

                                final ProgressDialog progressDialog = new ProgressDialog(SettingsActivity.this,
                                        R.style.Theme_AppCompat_Light_Dialog);
                                progressDialog.setIndeterminate(true);
                                progressDialog.setMessage("Please wait...");
                                progressDialog.show();

                                new android.os.Handler().postDelayed(
                                        new Runnable() {
                                            public void run() {
                                                // On complete call either onLoginSuccess or onLoginFailed


                                                Response.Listener<String> responseListener=new Response.Listener<String>() {
                                                    @Override
                                                    public void onResponse(String response) {
                                                        try {
                                                            JSONObject jsonResponse=new JSONObject(response);
                                                            boolean success=jsonResponse.getBoolean("success");

                                                            if(!success){


                                                                Toast.makeText(getBaseContext(), "There was an error\nPlease check internet connection and try again", Toast.LENGTH_LONG).show();


                                                                progressDialog.dismiss();

                                                            }else{



                                                                SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),SettingsActivity.this.MODE_PRIVATE);
                                                                SharedPreferences.Editor editor = sharedPref.edit();
                                                                //editor.putInt(getString(R.string.userId), userId);
                                                                editor.putString(getString(R.string.emailId), "");
                                                                editor.commit();
                                                                progressDialog.dismiss();
                                                                Toast.makeText(SettingsActivity.this,"Account deleted",Toast.LENGTH_LONG).show();
                                                                Intent intent = new Intent(SettingsActivity.this,LoginActivity.class);
                                                                startActivity(intent);

                                                                finish();

                                                            }

                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                };
                                                DeleteAccountRequest deleteAccountRequest=new DeleteAccountRequest(email,responseListener);
                                                RequestQueue queue = Volley.newRequestQueue(SettingsActivity.this);
                                                queue.add(deleteAccountRequest);

                                            }


                                        }, 3000);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                            }
                        });

                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Confirm Account Deletion");
                alert.setCancelable(true);
                alert.show();




            }
            });




        String finalSettings[];
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),SettingsActivity.this.MODE_PRIVATE);
        int preference = sharedPref.getInt(getString(R.string.preference),0);
        if (preference == 1) {
            /*settings[2] = "Create user";
            settings[3] = "Reports";*/
            finalSettings = adminSettings;
        }
        else {
            finalSettings = settings;
        }



        procedure = (ListView) findViewById(R.id.optionsList);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,finalSettings);
        procedure.setAdapter(adapter);

        procedure.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String cities = String.valueOf(parent.getItemAtPosition(position));
                        if(position == 0) {
                            Intent intent = new Intent(SettingsActivity.this,GeneralUserSettings.class);
                            startActivity(intent);
                        }

                        else if(position == 1) {
                            Intent intent = new Intent(SettingsActivity.this,MarksSettingsActivity.class);
                            startActivity(intent);
                        }

                        else if(position == 2) {
                            Intent intent = new Intent(SettingsActivity.this,CreateUserActivity.class);
                            startActivity(intent);
                        }

                        else if(position == 3) {
                            Intent intent = new Intent(SettingsActivity.this,ReportsActivity.class);
                            startActivity(intent);
                        }
                    }
                }
        );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {
            //call onBackPressed here
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
