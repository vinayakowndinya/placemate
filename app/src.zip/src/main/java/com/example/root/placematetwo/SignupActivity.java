package com.example.root.placematetwo;

import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class SignupActivity extends AppCompatActivity {
    String[] instructions = {
            "\n",
            "1. Contact your student placement coordinator",
            "2. Provide him/her with important details like email ID",
            "3. Get your default credentials through coordinator",
            "4. Login with default credentials provided to you",
            "5. Optionally, change your password for better security",
            "\n"
    };
    ListView procedure;
    ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

//        Window window = SignupActivity.this.getWindow();
//        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        window.setStatusBarColor(ContextCompat.getColor(SignupActivity.this, R.color.colorPrimaryDark));

//        ActionBar bar = getActionBar();
//        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#009b9b")));
//
//        bar.setTitle(Html.fromHtml("<font color='#ffffff'>Signup</font>"));

        procedure = (ListView) findViewById(R.id.procedure);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,instructions);
        procedure.setAdapter(adapter);
    }
}
