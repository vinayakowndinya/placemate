package com.example.root.placematetwo;

/**
 * Created by root on 2/2/18.
 */

public class BroadcastListElements {
    public String heading;
    public String date;
    public int broadcastId;


    public BroadcastListElements(int broadcastId,String heading,String date) {
        this.broadcastId = broadcastId;
        this.date = date;
        this.heading = heading;
    }
}
