package com.example.root.placematetwo;

/**
 * Created by root on 2/2/18.
 */

public class PlacedListElements {
    public String name;
    public String company;


    public PlacedListElements(String name,String company) {
        this.name = name;
        this.company = company;

    }
}
