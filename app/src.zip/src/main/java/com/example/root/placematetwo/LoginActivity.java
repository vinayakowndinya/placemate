package com.example.root.placematetwo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.content.Intent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;




import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;



public class LoginActivity extends Activity {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Window window = LoginActivity.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(LoginActivity.this, R.color.colorPrimaryDark));


        final EditText _emailText = (EditText) findViewById(R.id.input_email);
        final EditText _passwordText = (EditText) findViewById(R.id.input_password);
        final Button _loginButton = (Button) findViewById(R.id.btn_login);
        final TextView _signupLink = (TextView) findViewById(R.id.link_signup);

        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.d(TAG, "Login");

                //validation
                boolean valid = true;

                final String email = _emailText.getText().toString();
                final String password = _passwordText.getText().toString();
                final String username = email;
                if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    _emailText.setError("enter a valid email address");
                    valid = false;
                } else {
                    _emailText.setError(null);
                }

                if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
                    _passwordText.setError("between 4 and 10 alphanumeric characters");
                    valid = false;
                } else {
                    _passwordText.setError(null);
                }


                //after validation
                if(!valid) {//if invalid
                    Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

                    _loginButton.setEnabled(true);
                }

                else {//if valid
                    _loginButton.setEnabled(false);

                    final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this,
                            R.style.Theme_AppCompat_Light_Dialog);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setMessage("Authenticating...");
                    progressDialog.show();

                    new android.os.Handler().postDelayed(
                            new Runnable() {
                                public void run() {
                                    // On complete call either onLoginSuccess or onLoginFailed


                                    Response.Listener<String> responseListener=new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            try {
                                                JSONObject jsonResponse=new JSONObject(response);
                                                boolean success=jsonResponse.getBoolean("success");

                                                if(!success){


                                                    Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

                                                    _loginButton.setEnabled(true);
                                                    progressDialog.dismiss();

                                                }else{

                                                    String usn=jsonResponse.getString("usn");
                                                    String name=jsonResponse.getString("name");
                                                    String username=jsonResponse.getString("username");
                                                    String password=jsonResponse.getString("password");
                                                    String passout=jsonResponse.getString("passout");
                                                    int preference=jsonResponse.getInt("preference");

                                                    SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),LoginActivity.this.MODE_PRIVATE);
                                                    SharedPreferences.Editor editor = sharedPref.edit();
                                                    //editor.putInt(getString(R.string.userId), userId);
                                                    editor.putString(getString(R.string.emailId), _emailText.getText().toString());
                                                    editor.putString(getString(R.string.usn), usn);
                                                    editor.putString(getString(R.string.name), name);
                                                    editor.putString(getString(R.string.username), username);
                                                    editor.putString(getString(R.string.password), password);
                                                    editor.putString(getString(R.string.passout), passout);
                                                    editor.putInt(getString(R.string.preference), preference);
                                                    editor.commit();

                                                    FirebaseMessaging.getInstance().subscribeToTopic("notification");

                                                    progressDialog.dismiss();
                                                    Toast.makeText(getBaseContext(), "Login Success", Toast.LENGTH_LONG).show();


                                                    _loginButton.setEnabled(true);
                                                    Intent intent = new Intent(LoginActivity.this,ProfileActivity.class);
                                                    startActivity(intent);
                                                    finish();

                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };
                                    LoginRequest loginRequest=new LoginRequest(username,password,responseListener);
                                    RequestQueue queue = Volley.newRequestQueue(LoginActivity.this);
                                    queue.add(loginRequest);

                                }


                            }, 3000);

                }




            }
        });

        //calling signup activity
        _signupLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivityForResult(intent, REQUEST_SIGNUP);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here
                // By default we just finish the Activity and log them in automatically
                this.finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true);
    }

}


