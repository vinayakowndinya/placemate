package com.example.root.placematetwo;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by root on 28/2/18.
 */

public class DeleteAccountRequest extends StringRequest {
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/deleteAccountBackend.php";
    private Map<String,String> params;

    public DeleteAccountRequest(String email, Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("email",email);


    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}
