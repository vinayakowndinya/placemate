package com.example.root.placematetwo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import static java.sql.Types.NULL;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        final EditText sem_i = (EditText) findViewById(R.id.input_sem1);
        final EditText sem_ii = (EditText) findViewById(R.id.input_sem2);
        final EditText sem_iii = (EditText) findViewById(R.id.input_sem3);
        final EditText sem_iv = (EditText) findViewById(R.id.input_sem4);
        final EditText sem_v = (EditText) findViewById(R.id.input_sem5);
        final EditText sem_vi = (EditText) findViewById(R.id.input_sem6);
        final EditText sem_vii = (EditText) findViewById(R.id.input_sem7);
        final EditText sem_viii = (EditText) findViewById(R.id.input_sem8);
        final Button _profile_btn = (Button) findViewById(R.id.btn_profile);
        final TextView _skip_link = (TextView) findViewById(R.id.link_skip);

        /*sem_i.setText("0");
        sem_ii.setText("0");
        sem_iii.setText("0");
        sem_iv.setText("0");
        sem_v.setText("0");
        sem_vi.setText("0");
        sem_vii.setText("0");
        sem_viii.setText("0");*/

        final String update = "0";
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),ProfileActivity.this.MODE_PRIVATE);
        final String email = sharedPref.getString(getString(R.string.emailId), "");
        final int spProfile = sharedPref.getInt(getString(R.string.profile),0);
        if (spProfile==1)
        {
            Intent alreadyEntered = new Intent(ProfileActivity.this, MainActivity.class);
            startActivity(alreadyEntered);
            finish();
        }

        _skip_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),ProfileActivity.this.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt(getString(R.string.profile), 1);
                editor.commit();

                Intent alreadyEntered = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(alreadyEntered);
                finish();
            }
        });


        _profile_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strSem1 = sem_i.getText().toString();
                String strSem2 = sem_ii.getText().toString();
                String strSem3 = sem_iii.getText().toString();
                String strSem4 = sem_iv.getText().toString();
                String strSem5 = sem_v.getText().toString();
                String strSem6 = sem_vi.getText().toString();
                String strSem7 = sem_vii.getText().toString();
                String strSem8 = sem_viii.getText().toString();

                Boolean valid = true;

                //checking if sem 2 to 6 are empty and set the value of others
                if(strSem1.isEmpty())
                    sem_i.setText("0");

                if(strSem2.isEmpty())
                    sem_ii.setText("0");

                if(strSem3.isEmpty()) {
                    sem_iii.setError("Cannot be empty");
                    sem_iii.setText("0");
                }
                if(strSem4.isEmpty()) {
                    sem_iv.setError("Cannot be empty");
                    sem_iv.setText("0");
                }

                if(strSem5.isEmpty()) {
                    sem_v.setError("Cannot be empty");
                    sem_v.setText("0");
                }

                if(strSem6.isEmpty()) {
                    sem_vi.setError("Cannot be empty");
                    sem_vi.setText("0");
                }

                if(strSem7.isEmpty())
                    sem_vii.setText("0");

                if(strSem8.isEmpty())
                    sem_viii.setText("0");


                final float sem1 = Float.valueOf(sem_i.getText().toString());
                final float sem2 = Float.valueOf(sem_ii.getText().toString());
                final float sem3 = Float.valueOf(sem_iii.getText().toString());
                final float sem4 = Float.valueOf(sem_iv.getText().toString());
                final float sem5 = Float.valueOf(sem_v.getText().toString());
                final float sem6 = Float.valueOf(sem_vi.getText().toString());
                final float sem7 = Float.valueOf(sem_vii.getText().toString());
                final float sem8 = Float.valueOf(sem_viii.getText().toString());
                

                //checking if any value is out of bound
                if(sem1>100){
                    sem_i.setError("Invalid value");
                    valid = false;
                }
                if(sem2>100){
                    sem_ii.setError("Invalid value");
                    valid = false;
                }
                if(sem3==0||sem3>100){
                    sem_iii.setError("Invalid value");
                    valid = false;
                }
                if(sem4==0||sem4>100){
                    sem_iv.setError("Invalid value");
                    valid = false;
                }
                if(sem5==0||sem5>100){
                    sem_v.setError("Invalid value");
                    valid = false;
                }
                if(sem6==0||sem6>100){
                    sem_vi.setError("Invalid value");
                    valid = false;
                }
                if(sem7>100){
                    sem_vii.setError("Invalid value");
                    valid = false;
                }
                if(sem8>100){
                    sem_viii.setError("Invalid value");
                    valid = false;
                }

                //after validation
                if(!valid) {//if invalid
                    Toast.makeText(getBaseContext(), "Sem 3 to 6 cannot be empty\nor Invalid percentage", Toast.LENGTH_LONG).show();

                    _profile_btn.setEnabled(true);
                }

                //if valid
                else {
                    _profile_btn.setEnabled(false);

                    final ProgressDialog progressDialog = new ProgressDialog(ProfileActivity.this,
                            R.style.Theme_AppCompat_Light_Dialog);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setMessage("Updating...");
                    progressDialog.show();

                    new android.os.Handler().postDelayed(
                            new Runnable() {
                                public void run() {
                                    // On complete call either onLoginSuccess or onLoginFailed


                                    Response.Listener<String> responseListener=new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            try {

                                                JSONObject jsonResponse=new JSONObject(response);
                                                boolean success=jsonResponse.getBoolean("success");




                                                if(!success){


                                                    Toast.makeText(getBaseContext(), "Marks update failed", Toast.LENGTH_LONG).show();

                                                    _profile_btn.setEnabled(true);
                                                    progressDialog.dismiss();

                                                }else{


                                                    SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key),ProfileActivity.this.MODE_PRIVATE);
                                                    SharedPreferences.Editor editor = sharedPref.edit();
                                                    editor.putInt(getString(R.string.profile), 1);
                                                    editor.putInt(getString(R.string.marks),1);
                                                    editor.putFloat(getString(R.string.sem_i),sem1);
                                                    editor.putFloat(getString(R.string.sem_ii),sem2);
                                                    editor.putFloat(getString(R.string.sem_iii),sem3);
                                                    editor.putFloat(getString(R.string.sem_iv),sem4);
                                                    editor.putFloat(getString(R.string.sem_v),sem5);
                                                    editor.putFloat(getString(R.string.sem_vi),sem6);
                                                    editor.putFloat(getString(R.string.sem_vii),sem7);
                                                    editor.putFloat(getString(R.string.sem_viii),sem8);
                                                    editor.commit();

                                                    progressDialog.dismiss();
                                                    Toast.makeText(getBaseContext(), "Successfully updated", Toast.LENGTH_LONG).show();


                                                    _profile_btn.setEnabled(true);
                                                    /*Intent intent = new Intent(ProfileActivity.this,MainActivity.class);
                                                    startActivity(intent);
                                                    finish();*/

                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };


                                    ProfileUpdateRequest profileUpdateRequest = new ProfileUpdateRequest(sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,update,email,responseListener);
                                    RequestQueue queue = Volley.newRequestQueue(ProfileActivity.this);
                                    queue.add(profileUpdateRequest);
                                }


                            }, 3000);
                }
                
            }
        });


    }
}
