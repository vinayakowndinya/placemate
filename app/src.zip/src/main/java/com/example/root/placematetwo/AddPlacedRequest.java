package com.example.root.placematetwo;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by root on 03/09/18.
 */

public class AddPlacedRequest extends StringRequest {
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/addPlacedBackend.php";
    private Map<String,String> params;

    public AddPlacedRequest(String usn,String name, String company, Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("usn",name+"\n"+usn);
        params.put("company",company);
        params.put("imageLink",usn+".png");
        params.put("driveId","");


    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}
