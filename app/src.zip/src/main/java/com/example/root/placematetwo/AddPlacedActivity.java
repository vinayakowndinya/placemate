package com.example.root.placematetwo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AddPlacedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_placed);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.add_broadcast_activity_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        LayoutInflater li = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        li.inflate(R.layout.activity_add_broadcast,null);

        final EditText et_usn = (EditText) findViewById(R.id.input_usn);
        final EditText et_name = (EditText) findViewById(R.id.input_name);
        final EditText et_company = (EditText) findViewById(R.id.input_company);


        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_send) {

            final String usn = et_usn.getText().toString();
            final String name = et_name.getText().toString();
            final String company = et_company.getText().toString();

            Boolean valid = true;
            if(usn.isEmpty() || !usn.matches("[0-9]{1}[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{3}")) {
                et_usn.setError("invalid USN");
                valid = false;
            }
            if(name.isEmpty()) {
                et_name.setError("cannot be empty");
                valid = false;
            }
            if(company.isEmpty()) {
                et_company.setError("cannot be empty");
                valid = false;
            }

            if(valid) {

                final ProgressDialog progressDialog = new ProgressDialog(AddPlacedActivity.this,
                        R.style.Theme_AppCompat_Light_Dialog);
                progressDialog.setIndeterminate(true);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();

                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                // On complete call either onLoginSuccess or onLoginFailed


                                Response.Listener<String> responseListener = new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                        try {
                                            JSONObject jsonResponse = new JSONObject(response);
                                            final int total = jsonResponse.getInt("total");
                                            if (total == 0) {


                                                Toast.makeText(AddPlacedActivity.this, "Sorry! Unable to add. Please check internet connection", Toast.LENGTH_SHORT).show();
                                                progressDialog.dismiss();

                                            } else {


                                                progressDialog.dismiss();
                                                Toast.makeText(AddPlacedActivity.this, "Successfully added the info", Toast.LENGTH_SHORT).show();

                                                Intent intent = new Intent(AddPlacedActivity.this, MainActivity.class);
                                                startActivity(intent);


                                            }

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                };


                                AddPlacedRequest addPlacedRequest = new AddPlacedRequest(usn,name,company,responseListener);
                                RequestQueue queue = Volley.newRequestQueue(AddPlacedActivity.this);
                                queue.add(addPlacedRequest);
                            }


                        }, 3000);
            } else {
                Toast.makeText(AddPlacedActivity.this,"Fields cannot be empty",Toast.LENGTH_SHORT).show();
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
