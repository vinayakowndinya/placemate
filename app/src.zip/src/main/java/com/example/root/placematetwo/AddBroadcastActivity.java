package com.example.root.placematetwo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AddBroadcastActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_broadcast);

        /*final EditText heading = (EditText) findViewById(R.id.input_heading);
        final EditText msgBody = (EditText) findViewById(R.id.input_body);
        final Button sendbtn = (Button) findViewById(R.id.btn_submit);*/





            /*SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key), AddBroadcastActivity.this.MODE_PRIVATE);
            final String username = sharedPref.getString(getString(R.string.username), "");

            sendbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    final String headingTxt = heading.getText().toString();
                    final String msgBodyTxt = msgBody.getText().toString();
                    Boolean valid = true;
                    if(headingTxt.isEmpty()) {
                        heading.setError("cannot be empty");
                        valid = false;
                    }
                    if(msgBodyTxt.isEmpty()) {
                        msgBody.setError("cannot be empty");
                        valid = false;
                    }

                    if(valid) {

                    final ProgressDialog progressDialog = new ProgressDialog(AddBroadcastActivity.this,
                            R.style.Theme_AppCompat_Light_Dialog);
                    progressDialog.setIndeterminate(true);
                    progressDialog.setMessage("Please wait...");
                    progressDialog.show();

                    new android.os.Handler().postDelayed(
                            new Runnable() {
                                public void run() {
                                    // On complete call either onLoginSuccess or onLoginFailed


                                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            try {
                                                JSONObject jsonResponse = new JSONObject(response);
                                                final int total = jsonResponse.getInt("total");
                                                if (total == 0) {


                                                    Toast.makeText(AddBroadcastActivity.this, "Sorry! Unable to send", Toast.LENGTH_SHORT).show();
                                                    progressDialog.dismiss();

                                                } else {


                                                    progressDialog.dismiss();
                                                    Toast.makeText(AddBroadcastActivity.this, "Successfully broadcasted message", Toast.LENGTH_SHORT).show();

                                                    Intent intent = new Intent(AddBroadcastActivity.this, MainActivity.class);
                                                    startActivity(intent);


                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };


                                    AddBroadcastRequest addBroadcastRequest = new AddBroadcastRequest(username, headingTxt, msgBodyTxt, responseListener);
                                    RequestQueue queue = Volley.newRequestQueue(AddBroadcastActivity.this);
                                    queue.add(addBroadcastRequest);
                                }


                            }, 3000);
                } else {
                        Toast.makeText(AddBroadcastActivity.this,"Fields cannot be empty",Toast.LENGTH_SHORT).show();
                    }
            }
        });*/



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.add_broadcast_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        LayoutInflater li = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        li.inflate(R.layout.activity_add_broadcast,null);

        final EditText msgHead = (EditText) findViewById(R.id.input_heading);
        final EditText msgBody = (EditText) findViewById(R.id.input_body);

        int id = item.getItemId();
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.preference_file_key), AddBroadcastActivity.this.MODE_PRIVATE);
        final String username = sharedPref.getString(getString(R.string.username), "");

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_send) {
            //Toast.makeText(AddBroadcastActivity.this, "hello",Toast.LENGTH_SHORT).show();

            /*String headingTxt = msgHead.getText().toString();
            String msgBodyTxt = msgBody.getText().toString();*/
            //msgBody.setText("hi" + " " + headingTxt + msgBodyTxt);

            final String headingTxt = msgHead.getText().toString();
            final String msgBodyTxt = msgBody.getText().toString();
            Boolean valid = true;
            if(headingTxt.isEmpty()) {
                msgHead.setError("cannot be empty");
                valid = false;
            }
            if(msgBodyTxt.isEmpty()) {
                msgBody.setError("cannot be empty");
                valid = false;
            }

            if(valid) {

                final ProgressDialog progressDialog = new ProgressDialog(AddBroadcastActivity.this,
                        R.style.Theme_AppCompat_Light_Dialog);
                progressDialog.setIndeterminate(true);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();

                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                // On complete call either onLoginSuccess or onLoginFailed


                                Response.Listener<String> responseListener = new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                        try {
                                            JSONObject jsonResponse = new JSONObject(response);
                                            final int total = jsonResponse.getInt("total");
                                            if (total == 0) {


                                                Toast.makeText(AddBroadcastActivity.this, "Sorry! Unable to send", Toast.LENGTH_SHORT).show();
                                                progressDialog.dismiss();

                                            } else {


                                                progressDialog.dismiss();
                                                Toast.makeText(AddBroadcastActivity.this, "Successfully broadcasted message", Toast.LENGTH_SHORT).show();

                                                Intent intent = new Intent(AddBroadcastActivity.this, MainActivity.class);
                                                startActivity(intent);


                                            }

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                };


                                AddBroadcastRequest addBroadcastRequest = new AddBroadcastRequest(username, headingTxt, msgBodyTxt, responseListener);
                                RequestQueue queue = Volley.newRequestQueue(AddBroadcastActivity.this);
                                queue.add(addBroadcastRequest);
                            }


                        }, 3000);
            } else {
                Toast.makeText(AddBroadcastActivity.this,"Fields cannot be empty",Toast.LENGTH_SHORT).show();
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
