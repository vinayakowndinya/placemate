package com.example.root.placematetwo;


import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by root on 30/1/18.
 */

public class BroadcastRecieveRequest extends StringRequest {
    public static final String LOGIN_REQUEST_URL="http://gecprojectgroup2017.000webhostapp.com/getBroadcastMessages.php";
    private Map<String,String> params;

    public BroadcastRecieveRequest(Response.Listener<String > listener){
        super(Request.Method.POST,LOGIN_REQUEST_URL,listener,null);
        params=new HashMap<>();



    }

    @Override
    public Map<String,String> getParams(){
        return params;
    }
}